# Lightbench — Windows quick start

Lightbench makes three display outputs for a supported image: a JPG, an SVG containing a lossless full-resolution PNG, and a compressed SVGZ containing the exact JPG. These SVG files are raster backed; neither adds missing detail or becomes editable vector geometry. All outputs and a provenance report are placed beside your source image. Your source is not changed.

1. Install Python 3 for Windows with its `py` launcher.
2. Unzip this package and run `setup_windows.bat` once.
3. Drag an image onto one of these **three labelled workflows**:

| Launcher | JPG dimensions | JPG size |
| --- | --- | --- |
| `drop_image_here.bat` | Same as input after EXIF orientation | Automatic JPEG quality 88; size varies. |
| `try_jpg_budget.bat` | Same as input after EXIF orientation | You enter a KiB cap (4–20000), or press Enter for automatic quality 88. If the cap cannot fit at quality 1, it reports the required minimum and writes no outputs. |
| `drop_small_image_here.bat` | At most 768 pixels wide; may shrink more to fit | At most 144 KiB. |

Accepted input formats: **JPEG/JPG, PNG, WebP, BMP, single-frame GIF, and supported single-frame TIFF**. Detection uses file content. Supported color modes are RGB, RGBA, L, LA, and P. Animated files, high-bit-depth TIFFs and other unsupported modes stop with an error; HEIC, RAW, SVG, PDF, and arbitrary files are not accepted. Input bounds: 32 MiB file size and 16 million pixels. The full-pixel SVG retains decoded RGBA pixels and transparency after EXIF orientation, but does not embed the original container, source metadata, or color profile. For JPG, transparency is placed over white. The compact SVGZ contains the exported JPG, so its detail depends on the JPG settings.

For a separate native-shape approximation, use `lightbench.py` from a terminal:

```bat
py -3 lightbench.py "C:\path\to\photo.png" --width 768 --target-kib 700 --jpeg-kib 144 --out "C:\path\to\vector_result"
```

That experimental rectangle-vector path is slower and separate from the three drag launchers. See `LIGHTBENCH_RELEASE_README.md` for its options. To check the compact export and full-pixel SVG on a bundled fixture, run `py -3 compare_export.py`. The launchers were inspected and the Python workflows tested here; the Windows batch files have not been executed on Windows in this workspace.

## Experimental vector refinement (fourth, slower launcher)

Drag an image onto `drop_refine_vector_here.bat` to generate a bounded color-rectangle SVG, inspect its source-versus-render error, and append up to 2,048 source-derived 1×1 correction shapes in ten high-error 32×32 tiles. Open `*_vector_trial_viewer.html` beside the source image to switch views and toggle the baseline error overlay. This operation can be much slower and produces larger files than the three display workflows. It keeps the original image unchanged. The correction reads the source image; it cannot invent absent source detail. Baseline SVGZ has a 2,400 KiB cap; the refined SVGZ may exceed it by the cost of the correction layer. The report gives actual bytes, hashes, and error measurements. This path is an experiment rather than part of the three export presets.
