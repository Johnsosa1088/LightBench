# Lightbench — public preview candidate

Lightbench is a local, source-conditioned image exporter. Its three Windows drag launchers export JPG, raster-backed full-pixel SVG, raster-backed compact SVGZ, and a JSON provenance report. Choose native-size automatic JPG, native-size JPG with a requested byte cap, or a small JPG under 144 KiB. See `START_HERE_WINDOWS.md` for install, supported formats, and limitations. No private Aurelia image or CLCE source archive is included.

## Optional shape-vector experiment

`lightbench.py` is a separate command-line approximation using solid-color SVG rectangles. It writes a native-shape SVG, SVGZ, PNG preview and optional JPG. That SVG is editable as shapes, but the image is approximated and may look blocky. Run:

```sh
python3 lightbench.py photo.png --width 768 --target-kib 700 --jpeg-kib 144 --out vector_result
```

`--target-kib` caps its SVGZ; `--jpeg-kib` separately caps its optional JPG. Use `--roi X0 Y0 X1 Y1` in output-grid pixels to prioritize a rectangular area; `--roi-weight 0.8` changes that region's error threshold. This is not object recognition. For a particular image in a ZIP, `--member` selects an exact path and `--sha256` can enforce an independently verified source hash. It reads image bytes and does not execute archive members. For untrusted ZIPs, conduct a separate archive safety and integrity check first.

## Bounds and verification

Tested here with Python 3.12, Pillow 12.3.0 and NumPy 2.3.5, installed from `requirements.txt`. The display exporter checks the decoded input format and mode and bounds source bytes, pixel count and frame count. `compare_export.py` checks the bundled fixture: source is unchanged, output sizes and hashes match the report, the SVGZ embeds the exported JPG exactly, and the SVG embeds lossless RGBA pixels at the original oriented dimensions. A byte hash against the original compact JPG is pinned to this Pillow encoder version. JPEG is lossy; the SVG cannot create more detail than the pixels it embeds. The optional shape-vector path is constrained to a maximum 2 million pixel output grid.

This preview does not implement large scientific imagery, 16-bit preservation, ICC-managed rendering, or arbitrarily large tiled output. See `PORT_CONTRACT.md` for the precise adapter boundaries. There is no public license grant included; the project owner should select distribution terms before presenting this as open-source software.

## Experimental one-drag vector refinement

`drop_refine_vector_here.bat` runs a separate, slower source-conditioned rectangle-vector pass, measures its RGB residual against the input at the vector grid, appends up to 2,048 one-pixel correction rectangles in ten high-error tiles, and writes a local `*_viewer.html` with an on/off error overlay. The new SVGZ can exceed the 2,400 KiB baseline cap by the correction layer. This is an experiment, not the three fast display presets; a correction requires access to the source pixels.
