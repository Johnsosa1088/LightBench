"""Local image -> bounded shape SVG -> source-aware residual correction + viewer."""
import argparse
import gzip
import html
import hashlib
import json
import math
import subprocess
import sys
from pathlib import Path

import numpy as np
from PIL import Image

from lightbench import load_image


def refine(image_path):
    path = Path(image_path).resolve()
    if path.stat().st_size > 32*1024*1024:
        raise ValueError('Source exceeds 32 MiB')
    data, source = load_image(path, None, 32*1024*1024, 16_000_000)
    width = min(source.width, 1200, int(math.sqrt(1_990_000*source.width/source.height)))
    if width < 64:
        raise ValueError('Image aspect ratio outside this vector grid')
    prefix = path.with_name(path.stem + '_vector_trial')
    command = [sys.executable, str(Path(__file__).with_name('lightbench.py')),
               str(path), '--width', str(width), '--target-kib', '2400', '--out', str(prefix)]
    print(f'Building {width}-wide shape vector; this may take a minute...',flush=True)
    run = subprocess.run(command, capture_output=True, text=True)
    if run.returncode:
        raise ValueError('Baseline vector failed: ' + (run.stderr.strip() or run.stdout.strip()))
    print('Measuring source-versus-vector error and writing the correction layer...',flush=True)
    baseline_png = prefix.with_name(prefix.name+'_preview.png')
    baseline_svg = prefix.with_suffix('.svg')
    original = np.asarray(source.resize(Image.open(baseline_png).size, Image.Resampling.LANCZOS),dtype=np.uint8)
    baseline = np.asarray(Image.open(baseline_png).convert('RGB'),dtype=np.uint8)
    H,W = baseline.shape[:2]
    error = np.square(original.astype(np.float32)-baseline.astype(np.float32)).sum(axis=2)
    T = 32
    tiles = []
    for y in range(0,H,T):
        for x in range(0,W,T):
            block = error[y:min(y+T,H),x:min(x+T,W)]
            tiles.append((float(block.mean()),x,y))
    chosen=sorted(tiles,reverse=True)[:10]
    mask=np.zeros((H,W),dtype=bool)
    for _,x,y in chosen:mask[y:min(y+T,H),x:min(x+T,W)]=True
    ys,xs=np.where(mask)
    rank=np.argsort(error[ys,xs])[::-1]
    chosen_indices=rank[:min(2048,int((error[ys,xs]>0).sum()))]
    yy,xx=ys[chosen_indices],xs[chosen_indices]
    corrected=baseline.copy();corrected[yy,xx]=original[yy,xx]
    lines=[]
    for y,x in zip(yy,xx):
        r,g,b=map(int,original[y,x])
        lines.append(f'<rect x="{x}" y="{y}" width="1" height="1" fill="#{r:02x}{g:02x}{b:02x}"/>\n')
    svg=baseline_svg.read_bytes()
    if svg.count(b'</g>')!=1:
        raise ValueError('Unexpected vector SVG group structure')
    refined=svg.replace(b'</g>',''.join(lines).encode('ascii')+b'</g>')
    revised_svg=prefix.with_name(prefix.name+'_refined.svg')
    revised_svgz=prefix.with_name(prefix.name+'_refined.svgz')
    revised_png=prefix.with_name(prefix.name+'_refined.png')
    source_png=prefix.with_name(prefix.name+'_source.png')
    heat_png=prefix.with_name(prefix.name+'_error.png')
    revised_svg.write_bytes(refined)
    revised_svgz.write_bytes(gzip.compress(refined,compresslevel=9,mtime=0))
    Image.fromarray(corrected).save(revised_png)
    Image.fromarray(original).save(source_png)
    squared=(error/3)
    heat=np.sqrt(squared)
    vmax=max(float(np.percentile(heat,99)),0.1)
    h=np.clip(heat/vmax,0,1)
    display=np.stack((255*h,80*(1-h),145*(1-h)),axis=2).astype(np.uint8)
    Image.fromarray(display).save(heat_png)
    baseline_rmse=float(np.sqrt(squared.mean()))
    refined_rmse=float(np.sqrt(np.mean(np.square(original.astype(np.float32)-corrected.astype(np.float32)))))
    result={'schema':'LIGHTBENCH_DRAG_VECTOR_REFINE/1','source_sha256':hashlib.sha256(data).hexdigest(),
            'grid':[W,H],'baseline_svg_sha256':hashlib.sha256(svg).hexdigest(),
            'refined_svg_sha256':hashlib.sha256(refined).hexdigest(),
            'baseline_rmse':baseline_rmse,'refined_rmse':refined_rmse,
            'additional_rectangles':len(lines),'additional_svg_bytes':len(refined)-len(svg),
            'baseline_svgz_bytes':len(gzip.compress(svg,compresslevel=9,mtime=0)),
            'refined_svgz_bytes':revised_svgz.stat().st_size,
            'algorithm':'10 highest-RGB-error 32-pixel tiles; up to 2048 highest-error pixels corrected from source RGB',
            'scope':'source-conditioned vector overlay; no reconstruction without source',
            'files':{'viewer':prefix.with_name(prefix.name+'_viewer.html').name}}
    report=prefix.with_name(prefix.name+'_refine_report.json');report.write_text(json.dumps(result,indent=2)+'\n')
    viewer=prefix.with_name(prefix.name+'_viewer.html')
    images={'source':source_png.name,'baseline':baseline_png.name,'refined':revised_png.name,'error':heat_png.name}
    viewer.write_text('''<!doctype html><html lang="en"><meta charset="utf-8"><title>Lightbench vector refinement</title>
<style>body{font:16px system-ui;background:#13212d;color:white;padding:15px}button{padding:10px;margin:4px}#stage{max-width:850px;position:relative}img{width:100%%;display:block}#heat{position:absolute;inset:0;opacity:0;pointer-events:none}</style>
<h1>Vector refinement</h1><p>Baseline RMSE: %.4f · Refined RMSE: %.4f · Added shapes: %d</p>
<button onclick="show('source')">Source</button><button onclick="show('baseline')">Baseline SVG render</button><button onclick="show('refined')">Refined SVG render</button>
<label><input id="toggle" type="checkbox" onchange="update()"> Baseline error overlay</label>
<label>Opacity <input id="opacity" type="range" min="0" max="80" value="50" oninput="update()"></label>
<div id="stage"><img id="main" src="%s"><img id="heat" src="%s"></div>
<p>The overlay compares source with baseline. It remains the baseline error map while viewing the refined result.</p>
<script>const names=%s;function show(which){document.getElementById('main').src=names[which]}function update(){document.getElementById('heat').style.opacity=document.getElementById('toggle').checked?document.getElementById('opacity').value/100:0}</script>
</html>'''%(baseline_rmse,refined_rmse,len(lines),html.escape(baseline_png.name,quote=True),html.escape(heat_png.name,quote=True),json.dumps(images).replace('<','\\u003c')))
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('image',type=Path);a=p.parse_args()
    print(json.dumps(refine(a.image),indent=2))

if __name__=='__main__':main()
