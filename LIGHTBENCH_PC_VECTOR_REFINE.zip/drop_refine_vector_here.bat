@echo off
if "%~1"=="" (
  echo Drag a supported image file onto this .bat file.
  pause
  exit /b 1
)
py -3 "%~dp0drag_vector_refine.py" "%~1"
if errorlevel 1 (
  echo Vector refinement failed. Check the error shown above.
  pause
  exit /b 1
)
echo Finished. Open the *_vector_trial_viewer.html beside your input image.
pause
