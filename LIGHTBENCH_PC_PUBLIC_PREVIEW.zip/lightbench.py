"""Public image-to-native-SVG budget tool. Source-conditioned, no image synthesis."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
from zipfile import ZipFile

import numpy as np
from PIL import Image, ImageOps


def jpeg_under_budget(image, cap):
    best = None
    for quality in range(1, 96):
        out = io.BytesIO()
        image.save(out, 'JPEG', quality=quality, subsampling=0,
                   optimize=True, progressive=True)
        data = out.getvalue()
        if len(data) <= cap and (best is None or quality > best[0]):
            best = (quality, data)
    return best


def load_image(path, member, max_source_bytes, max_pixels):
    if member:
        with ZipFile(path) as archive:
            info = archive.getinfo(member)
            if info.is_dir() or info.file_size > max_source_bytes:
                raise ValueError('Archive member is a directory or too large')
            data = archive.read(info)
    else:
        if path.stat().st_size > max_source_bytes:
            raise ValueError('Image file is too large')
        data = path.read_bytes()
    Image.MAX_IMAGE_PIXELS = max_pixels
    with Image.open(io.BytesIO(data)) as image:
        if image.width * image.height > max_pixels or getattr(image, 'n_frames', 1) != 1:
            raise ValueError('Image exceeds pixel limit or has multiple frames')
        rgb = ImageOps.exif_transpose(image).convert('RGB')
    return data, rgb


def vectorize(target, limit, roi, roi_weight):
    height, width = target.shape[:2]
    sums = np.pad(target, ((1, 0), (1, 0), (0, 0))).cumsum(0).cumsum(1)
    squares = np.pad(target * target, ((1, 0), (1, 0), (0, 0))).cumsum(0).cumsum(1)
    rects = []

    def box(a, x0, y0, x1, y1):
        return a[y1, x1] - a[y0, x1] - a[y1, x0] + a[y0, x0]

    def visit(x0, y0, x1, y1):
        n = (x1-x0)*(y1-y0)
        avg = box(sums, x0, y0, x1, y1)/n
        variance = np.maximum(0, box(squares, x0, y0, x1, y1)/n - avg*avg)
        focused = roi and x0 < roi[2] and x1 > roi[0] and y0 < roi[3] and y1 > roi[1]
        if np.sqrt(variance.mean()) <= limit*(roi_weight if focused else 1) or n == 1:
            rects.append((x0, y0, x1-x0, y1-y0,
                          *(int(np.floor(v+.5)) for v in avg)))
            return
        mx, my = (x0+x1)//2, (y0+y1)//2
        if x1-x0 > 1 and y1-y0 > 1:
            for b in ((x0,y0,mx,my),(mx,y0,x1,my),(x0,my,mx,y1),(mx,my,x1,y1)):
                visit(*b)
        elif x1-x0 > 1:
            visit(x0,y0,mx,y1); visit(mx,y0,x1,y1)
        else:
            visit(x0,y0,x1,my); visit(x0,my,x1,y1)

    visit(0, 0, width, height)
    lines = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
             '<title>Source-conditioned vector approximation</title>',
             '<g shape-rendering="crispEdges">']
    lines.extend(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="#{r:02x}{g:02x}{b:02x}"/>'
                 for x,y,w,h,r,g,b in rects)
    lines.extend(('</g>','</svg>'))
    svg = ('\n'.join(lines)+'\n').encode()
    return rects, svg, gzip.compress(svg, compresslevel=9, mtime=0)


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('input', type=Path, help='Local image, or ZIP if --member is set')
    p.add_argument('--member', help='Exact image member name in a ZIP')
    p.add_argument('--sha256', help='Required exact source SHA-256 for untrusted input')
    p.add_argument('--target-kib', type=int, default=700)
    p.add_argument('--width', type=int, default=768)
    p.add_argument('--roi', type=int, nargs=4, metavar=('X0','Y0','X1','Y1'),
                   help='Optional pixel-space priority window on the output grid')
    p.add_argument('--roi-weight', type=float, default=0.8)
    p.add_argument('--jpeg-kib', type=int, help='Optional maximum display JPG size')
    p.add_argument('--out', type=Path, default=Path('lightbench_output'))
    a = p.parse_args(argv)
    if not 64 <= a.width <= 1600 or not 16 <= a.target_kib <= 20000:
        p.error('width must be 64..1600 and target-kib 16..20000')
    if not .3 <= a.roi_weight <= 1 or (a.jpeg_kib is not None and not 4 <= a.jpeg_kib <= 20000):
        p.error('roi-weight must be 0.3..1; jpeg-kib must be 4..20000')
    data, image = load_image(a.input, a.member, 32*1024*1024, 16_000_000)
    source_hash = hashlib.sha256(data).hexdigest()
    if a.sha256 and source_hash != a.sha256.lower():
        raise ValueError('Source SHA-256 mismatch')
    height = round(image.height*a.width/image.width)
    if height < 1 or a.width*height > 2_000_000:
        p.error('Output grid outside supported bounds')
    roi = a.roi
    if roi and not (0 <= roi[0] < roi[2] <= a.width and 0 <= roi[1] < roi[3] <= height):
        p.error('ROI must be inside the output image')
    target = np.asarray(image.resize((a.width,height), Image.Resampling.LANCZOS), dtype=np.float64)
    budget = a.target_kib*1024
    lo, hi, best, trials = .2, 50., None, []
    for _ in range(11):
        threshold = (lo+hi)/2
        candidate = vectorize(target, threshold, roi, a.roi_weight)
        trials.append({'threshold':threshold,'svgz_bytes':len(candidate[2])})
        if len(candidate[2]) <= budget:
            best = (threshold, candidate)
            hi = threshold
        else:
            lo = threshold
    if best is None:
        raise ValueError('Budget cannot be met at this grid; increase target-kib or lower width')
    threshold, (rects, svg, svgz) = best
    preview = np.empty((height,a.width,3),dtype=np.uint8)
    for x,y,w,h,r,g,b in rects:
        preview[y:y+h,x:x+w] = [r,g,b]
    img = Image.fromarray(preview)
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.with_suffix('.svg').write_bytes(svg)
    a.out.with_suffix('.svgz').write_bytes(svgz)
    img.save(a.out.with_name(a.out.name+'_preview.png'))
    diff = preview.astype(float)-target
    report = {'schema':'LIGHTBENCH_PUBLIC_RC1','source_sha256':source_hash,
              'source_image_dimensions':list(image.size),'grid':[a.width,height],
              'source_zip_member':a.member,'target_svgz_bytes':budget,
              'actual_svgz_bytes':len(svgz),'rectangles':len(rects),
              'threshold':threshold,'roi':roi,'roi_weight':a.roi_weight if roi else None,
              'rmse':float(np.sqrt(np.square(diff).mean())),
              'svg_sha256':hashlib.sha256(svg).hexdigest(),
              'svgz_sha256':hashlib.sha256(svgz).hexdigest(),
              'roundtrip_exact':gzip.decompress(svgz)==svg,
              'independent_generation':False,'canonical_writeback':False,
              'trials':trials}
    if a.jpeg_kib:
        cap = a.jpeg_kib*1024
        chosen = jpeg_under_budget(img,cap)
        if chosen is None:
            raise ValueError('Display JPG budget too small; output vector remains available')
        quality, jpg = chosen
        a.out.with_suffix('.jpg').write_bytes(jpg)
        decoded = np.asarray(Image.open(io.BytesIO(jpg)).convert('RGB'),dtype=float)
        report['display_jpeg'] = {'bytes':len(jpg),'byte_cap':cap,'quality':quality,
                                  'sha256':hashlib.sha256(jpg).hexdigest(),
                                  'rmse_vs_source':float(np.sqrt(np.square(decoded-target).mean()))}
    a.out.with_name(a.out.name+'_report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ('actual_svgz_bytes','rectangles','rmse')}))


if __name__ == '__main__':
    main()
