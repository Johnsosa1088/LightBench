"""Bounded file ports and output adapters for the fast Lightbench display path."""
import base64
import gzip
import hashlib


SUPPORTED_FORMATS = {'JPEG':'image/jpeg', 'PNG':'image/png', 'WEBP':'image/webp',
                     'BMP':'image/bmp', 'TIFF':'image/tiff', 'GIF':'image/gif'}
SAFE_MODES = {'RGB', 'RGBA', 'L', 'LA', 'P'}


def source_port(image, path, raw_hash, byte_count):
    media_type = SUPPORTED_FORMATS.get(image.format)
    if media_type is None or image.mode not in SAFE_MODES:
        raise ValueError(f'No display adapter for format={image.format}, mode={image.mode}; '
                         'scientific and high-bit-depth channels are not reduced silently')
    metadata = {}
    for key in ('exif', 'icc_profile'):
        value = image.info.get(key)
        if isinstance(value, bytes):
            metadata[key] = {'bytes':len(value),'sha256':hashlib.sha256(value).hexdigest()}
    return {'port_schema':'LIGHTBENCH_PORT/1', 'direction':'input',
            'source_name':path.name, 'source_sha256':raw_hash, 'source_bytes':byte_count,
            'media_type':media_type, 'dimensions':{'width':image.width,'height':image.height},
            'coordinate_space':{'type':'image/pixel','origin':'upper-left'},
            'channels':list(image.getbands()), 'native_mode':image.mode,
            'metadata':metadata,
            'metadata_retention':'summary in sidecar only; original source remains untouched',
            'adapter':'pillow/single-frame-rgb8',
            'constraints':{'max_source_bytes':32*1024*1024,
                           'max_source_pixels':16_000_000,'frames':1}}


def working_port(width, height, background, input_hash):
    return {'port_schema':'LIGHTBENCH_PORT/1', 'direction':'internal',
            'media_type':'image/x-rgb8',
            'dimensions':{'width':width,'height':height},
            'coordinate_space':{'type':'image/pixel','origin':'upper-left'},
            'channels':['R','G','B'],
            'profile':{'alpha_background':background},
            'provenance':{'source_sha256':input_hash,
                          'transform':'EXIF orientation; alpha composite; RGB conversion'}}


def svgz_from_jpg(jpg, display_size):
    """Output adapter: scalable SVG container, raster-backed by exact JPG bytes."""
    sw,sh=display_size
    encoded=base64.b64encode(jpg).decode('ascii')
    svg=('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" '
         'viewBox="0 0 %d %d"><title>Raster-backed Lightbench display copy</title>'
         '<image x="0" y="0" width="%d" height="%d" '
         'href="data:image/jpeg;base64,%s"/></svg>\n'
         % (sw,sh,sw,sh,sw,sh,encoded)).encode('utf-8')
    return gzip.compress(svg,compresslevel=9,mtime=0),svg


def svg_from_full_png(png, dimensions):
    """SVG container with the lossless full-size RGBA grid (no vector tracing)."""
    sw, sh = dimensions
    encoded = base64.b64encode(png).decode('ascii')
    return ('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" '
            'viewBox="0 0 %d %d"><title>Full-pixel raster-backed Lightbench copy</title>'
            '<image x="0" y="0" width="%d" height="%d" '
            'href="data:image/png;base64,%s"/></svg>\n'
            % (sw, sh, sw, sh, sw, sh, encoded)).encode('utf-8')


def output_port(media_type, path, data, size, source_hash, adapter, **additional):
    result={'port_schema':'LIGHTBENCH_PORT/1','direction':'output',
            'media_type':media_type,
            'dimensions':{'width':size[0],'height':size[1]},
            'coordinate_space':{'type':'image/pixel','origin':'upper-left'},
            'channels':['R','G','B'],
            'adapter':adapter, 'payload_ref':str(path),
            'payload_bytes':len(data),'payload_sha256':hashlib.sha256(data).hexdigest(),
            'provenance':{'source_sha256':source_hash}}
    result.update(additional)
    return result
