# Controlled fast export comparison

After `setup_windows.bat`, run `py -3 compare_export.py` to inspect the bundled fixture, or `py -3 compare_export.py "C:\\path\\to\\image.png" --json comparison.json` for your own image. The command exports into a temporary directory, leaves your image untouched, and prints a report. It verifies source and output hashes, budget, port identities, and that SVGZ embeds the exact JPG. The RGB RMSE compares the decoded JPG with the input resized to the exported grid; it measures pixel error, not visual quality or new detail.

The bundled fixture also checks its JPG hash against the original RC2 build. This byte check assumes the same Pillow JPEG encoder version and settings; a different Pillow version may produce different bytes while the other checks still pass. This tool accepts only formats and bounds supported by `compress_image.py`; it does not implement scientific raster or native vector adapters. The JPG and SVGZ bytes are created with the unmodified RC4 exporter.

The comparison also decodes the full-resolution PNG inside the `.svg` and checks its RGBA pixel values and dimensions against the EXIF-oriented source. It checks the new SVG and PNG hashes recorded in the report.
