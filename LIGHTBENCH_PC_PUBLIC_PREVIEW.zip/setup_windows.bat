@echo off
cd /d "%~dp0"
py -3 -m pip install -r "%~dp0requirements.txt"
if errorlevel 1 (
  echo Setup failed. Install Python 3 with the Windows py launcher, then rerun this file.
  pause
  exit /b 1
)
echo Setup complete. Drag an image onto drop_image_here.bat to make a JPG at the input dimensions.
pause
