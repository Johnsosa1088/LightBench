"""Inspect the fast export in isolation; this does not modify the source image."""
import argparse
import base64
import gzip
import hashlib
import io
import json
import subprocess
import sys
import tempfile
from pathlib import Path
from xml.etree import ElementTree

from PIL import Image, ImageChops, ImageOps, ImageStat


def sha(data):
    return hashlib.sha256(data).hexdigest()


def compare(source, target_kib=144, max_width=768):
    source = Path(source).resolve()
    source_bytes = source.read_bytes()
    with tempfile.TemporaryDirectory(prefix='lightbench_compare_') as temp:
        output = Path(temp) / 'export.jpg'
        command = [sys.executable, str(Path(__file__).with_name('compress_image.py')),
                   str(source), '--output', str(output), '--target-kib', str(target_kib),
                   '--max-width', str(max_width)]
        run = subprocess.run(command, capture_output=True, text=True)
        if run.returncode:
            raise RuntimeError(run.stderr.strip() or run.stdout.strip())
        jpg = output.read_bytes()
        svgz = output.with_suffix('.svgz').read_bytes()
        full_svg = output.with_suffix('.svg').read_bytes()
        report = json.loads(output.with_name('export_report.json').read_text())
        full_root = ElementTree.fromstring(full_svg)
        full_images = full_root.findall('.//{http://www.w3.org/2000/svg}image')
        if len(full_images) != 1:
            raise ValueError('Expected one full-pixel embedded image')
        full_href = full_images[0].get('href')
        if not full_href or not full_href.startswith('data:image/png;base64,'):
            raise ValueError('Full SVG missing PNG payload')
        full_png = base64.b64decode(full_href.split(',',1)[1],validate=True)
        root = ElementTree.fromstring(gzip.decompress(svgz))
        images = root.findall('.//{http://www.w3.org/2000/svg}image')
        if len(images) != 1:
            raise ValueError('Expected one embedded image')
        href = images[0].get('{http://www.w3.org/1999/xlink}href') or images[0].get('href')
        if not href or not href.startswith('data:image/jpeg;base64,'):
            raise ValueError('SVGZ missing JPG payload')
        embedded = base64.b64decode(href.split(',', 1)[1], validate=True)
        with Image.open(source) as original:
            original.load()
            original = ImageOps.exif_transpose(original).convert('RGBA')
            base = Image.new('RGBA', original.size, report['alpha_background'])
            rgb = Image.alpha_composite(base, original).convert('RGB')
        with Image.open(io.BytesIO(full_png)) as full_decoded:
            full_decoded.load()
            full_pixels = full_decoded.convert('RGBA')
        with Image.open(io.BytesIO(jpg)) as decoded:
            decoded.load()
            actual = decoded.convert('RGB')
        reference = rgb.resize(actual.size, Image.Resampling.LANCZOS) if rgb.size != actual.size else rgb
        differences = ImageStat.Stat(ImageChops.difference(reference, actual))
        rmse = (sum(v*v for v in differences.rms)/3)**0.5
        outputs = report['ports']['outputs']
        checks = {
            'source_unchanged': sha(source.read_bytes()) == sha(source_bytes),
            'jpg_within_budget': len(jpg) <= target_kib*1024,
            'svgz_embeds_exact_jpg': embedded == jpg,
            'report_source_hash': report['source_sha256'] == sha(source_bytes),
            'report_jpg_hash': report['jpeg_sha256'] == sha(jpg),
            'report_svgz_hash': report['svgz']['sha256'] == sha(svgz),
            'port_input_hash': report['ports']['input']['source_sha256'] == sha(source_bytes),
            'port_output_hashes': outputs[0]['payload_sha256'] == sha(jpg) and outputs[1]['payload_sha256'] == sha(svgz),
            'reported_dimensions': report['output_dimensions'] == list(actual.size),
            'svg_is_raster_backed': outputs[1]['native_vector_shapes'] is False,
            'full_svg_pixel_exact': full_pixels.size == original.size and full_pixels.tobytes() == original.tobytes(),
            'full_svg_report_hash': report['full_svg']['sha256'] == sha(full_svg),
            'full_svg_png_hash': report['full_svg']['embedded_png_sha256'] == sha(full_png),
            'full_svg_port_hash': outputs[2]['payload_sha256'] == sha(full_svg),
        }
        # The supplied fixture is pinned to the RC2 JPG on the same Pillow encoder.
        # Other Pillow versions can produce different JPEG bytes.
        if (sha(source_bytes) == 'db1ac9a27ba2efbe0ab7540c706207c4a91c9b7344d951292aaaaf82395c8fb0'
                and target_kib == 144 and max_width == 768):
            checks['rc2_fixture_jpg_identity'] = sha(jpg) == '1a72b90c882723cc5dfc2a515c985d609e2e6f014f7c1bf886c3d11403dbf0d6'
        return {'schema':'LIGHTBENCH_EXPORT_COMPARISON/1',
                'source':source.name,'source_dimensions':list(rgb.size),
                'source_sha256':sha(source_bytes),'output_dimensions':list(actual.size),
                'jpg_bytes':len(jpg),'jpg_sha256':sha(jpg),
                'svgz_bytes':len(svgz),'svgz_sha256':sha(svgz),
                'full_svg_bytes':len(full_svg),'full_svg_sha256':sha(full_svg),
                'working_grid_rgb_rmse':round(rmse,4),
                'jpeg_quality':report['jpeg_quality'],'checks':checks,
                'passed':all(checks.values())}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', nargs='?', type=Path, default=Path(__file__).with_name('release_fixture.png'))
    parser.add_argument('--target-kib',type=int,default=144)
    parser.add_argument('--max-width',type=int,default=768)
    parser.add_argument('--json',type=Path,help='Optional comparison report destination')
    args = parser.parse_args()
    result = compare(args.source,args.target_kib,args.max_width)
    rendered = json.dumps(result,indent=2)+'\n'
    print(rendered,end='')
    if args.json:
        args.json.write_text(rendered)
    if not result['passed']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
