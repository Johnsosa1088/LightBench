@echo off
if "%~1"=="" (
  echo Drag an image file onto this .bat file.
  pause
  exit /b 1
)
py -3 "%~dp0compress_image.py" "%~1" --target-kib 144 --max-width 768
if errorlevel 1 (
  echo Compact export failed. Check the error above.
  pause
  exit /b 1
)
echo Finished compact JPG, SVGZ, full-pixel SVG and report.
pause
