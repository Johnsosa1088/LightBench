@echo off
setlocal
if "%~1"=="" (
  echo Drag an image onto try_jpg_budget.bat.
  pause
  exit /b 1
)
set "budget=auto"
set /p "budget=JPG budget KiB [4..20000; Enter=auto quality 88]: "
if "%budget%"=="" set "budget=auto"
set "output=%~dpn1_%budget%_native.jpg"
py -3 "%~dp0compress_image.py" "%~1" --target-kib "%budget%" --native-dimensions --output "%output%"
if errorlevel 1 (
  echo Export failed. Choose auto or a larger integer budget; input dimensions are preserved.
  pause
  exit /b 1
)
echo Done. The JPG, SVGZ, full-pixel SVG and report use the chosen budget label.
pause
