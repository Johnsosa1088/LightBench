"""Portable display JPG exporter with a byte cap; independent of SVG generation."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path

from PIL import Image, ImageOps
from port_contract import output_port, source_port, svgz_from_jpg, svg_from_full_png, working_port


def encode_under_cap(image, cap):
    best = None
    # Testing the entire finite quality range avoids assuming JPEG byte sizes
    # are perfectly monotonic for all images and encoder configurations.
    for quality in range(1, 96):
        stream = io.BytesIO()
        image.save(stream, format='JPEG', quality=quality, subsampling=0,
                   optimize=True, progressive=True)
        data = stream.getvalue()
        if len(data) <= cap and (best is None or quality > best[0]):
            best = (quality, data)
    return best


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('image', type=Path, help='An image file, such as PNG or JPG')
    p.add_argument('--target-kib', default='144',
                   help='Maximum JPG size in KiB (4..20000), or auto for quality 88; default: 144')
    p.add_argument('--native-dimensions', action='store_true',
                   help='Keep oriented input width and height; fail if numeric budget cannot fit')
    p.add_argument('--max-width', type=int, default=768,
                   help='Scale down to at most this width (default: 768)')
    p.add_argument('--output', type=Path, help='Optional output JPG filename')
    p.add_argument('--background', default='#ffffff',
                   help='Color under transparent images (default: white)')
    a = p.parse_args(argv)
    if a.target_kib != 'auto':
        try:
            a.target_kib = int(a.target_kib)
        except ValueError:
            p.error('target-kib must be an integer 4..20000 or auto')
        if not 4 <= a.target_kib <= 20000:
            p.error('target-kib must be 4..20000')
    if not 64 <= a.max_width <= 4096:
        p.error('max-width must be 64..4096')
    if a.target_kib == 'auto' and not a.native_dimensions:
        p.error('auto target requires --native-dimensions')
    if a.image.stat().st_size > 32*1024*1024:
        p.error('Input exceeds the 32 MiB safety limit')
    raw = a.image.read_bytes()
    source_hash = hashlib.sha256(raw).hexdigest()
    Image.MAX_IMAGE_PIXELS = 16_000_000
    with Image.open(a.image) as loaded:
        if loaded.width*loaded.height > 16_000_000 or getattr(loaded, 'n_frames', 1) != 1:
            p.error('Input exceeds pixel limit or contains multiple frames')
        try:
            incoming = source_port(loaded,a.image,source_hash,len(raw))
        except ValueError as exc:
            p.error(str(exc))
        oriented = ImageOps.exif_transpose(loaded)
        rgba = oriented.convert('RGBA')
    full_pixel_stream = io.BytesIO()
    rgba.save(full_pixel_stream, format='PNG', optimize=True)
    full_png = full_pixel_stream.getvalue()
    try:
        background = Image.new('RGBA', rgba.size, a.background)
    except ValueError as exc:
        p.error(str(exc))
    rgb = Image.alpha_composite(background, rgba).convert('RGB')
    original_dims = list(rgb.size)
    normalized = working_port(rgb.width,rgb.height,a.background,source_hash)
    cap = None if a.target_kib == 'auto' else a.target_kib*1024
    if a.native_dimensions:
        scaled = rgb
        if cap is None:
            quality = 88
            stream = io.BytesIO()
            scaled.save(stream, format='JPEG', quality=quality, subsampling=0,
                        optimize=True, progressive=True)
            jpg = stream.getvalue()
        else:
            result = encode_under_cap(scaled, cap)
            if result is None:
                stream = io.BytesIO()
                scaled.save(stream, format='JPEG', quality=1, subsampling=0,
                            optimize=True, progressive=True)
                p.error(f'{a.target_kib} KiB cannot hold {scaled.width} x {scaled.height} '
                        f'even at JPEG quality 1 (needs at least {len(stream.getvalue())} bytes). '
                        'Choose a larger budget, auto, or the small-image drag option.')
            quality,jpg = result
    else:
        initial_width = min(rgb.width, a.max_width)
        chosen = None
        width = initial_width
        while width >= 64:
            height = max(1, round(rgb.height*width/rgb.width))
            scaled = rgb.resize((width,height),Image.Resampling.LANCZOS) if width != rgb.width else rgb
            result = encode_under_cap(scaled, cap)
            if result is not None:
                chosen = (scaled,result)
                break
            width = int(width*.85)
        if chosen is None:
            p.error('Could not reach requested size at minimum supported dimensions')
        scaled,(quality,jpg) = chosen
    output = a.output or a.image.with_name(a.image.stem+('_native.jpg' if a.native_dimensions else '_small.jpg'))
    if output.resolve() == a.image.resolve():
        p.error('Output must not overwrite the input')
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_bytes(jpg)
    # This fast companion is an SVG container displaying the exact JPG bytes.
    # It scales as SVG but does not turn the JPG pixels into native vector shapes.
    svgz, svg = svgz_from_jpg(jpg,original_dims)
    svgz_output = output.with_suffix('.svgz')
    svgz_output.write_bytes(svgz)
    full_svg = svg_from_full_png(full_png, original_dims)
    full_svg_output = output.with_suffix('.svg')
    full_svg_output.write_bytes(full_svg)
    jpg_port=output_port('image/jpeg',output,jpg,list(scaled.size),source_hash,
                         'pillow/jpeg-under-budget',channels=['R','G','B'])
    svgz_port=output_port('image/svg+xml+gzip',svgz_output,svgz,original_dims,source_hash,
                          'embedded-jpg/svgz',
                          embedded_media_type='image/jpeg',
                          embedded_jpg_sha256=jpg_port['payload_sha256'],
                          embedded_jpg_dimensions=list(scaled.size),
                          native_vector_shapes=False)
    full_svg_port = output_port('image/svg+xml', full_svg_output, full_svg, original_dims, source_hash,
                                'full-pixel-png/svg', channels=['R','G','B','A'],
                                embedded_media_type='image/png',
                                embedded_png_sha256=hashlib.sha256(full_png).hexdigest(),
                                embedded_png_dimensions=original_dims,
                                native_vector_shapes=False,
                                pixel_policy='EXIF orientation applied; original RGBA pixels preserved losslessly; source color profile metadata not embedded')
    report = {'schema':'LIGHTBENCH_DISPLAY_EXPORT/1','source_sha256':source_hash,
              'source_dimensions':original_dims,'output_dimensions':list(scaled.size),
              'target_bytes':cap,'budget_mode':('auto_quality_88' if cap is None else 'maximum_bytes'),
              'preserve_input_dimensions':a.native_dimensions,
              'output_bytes':len(jpg),'jpeg_quality':quality,
              'jpeg_sha256':hashlib.sha256(jpg).hexdigest(),
              'svgz':{'path':str(svgz_output),'bytes':len(svgz),
                      'sha256':hashlib.sha256(svgz).hexdigest(),
                      'kind':'raster-backed SVGZ; embeds exact output JPG, no native vector shapes',
                      'display_dimensions':original_dims,
                      'embedded_jpg_dimensions':list(scaled.size),
                      'svgz_roundtrip_exact':gzip.decompress(svgz)==svg},
              'full_svg':{'path':str(full_svg_output),'bytes':len(full_svg),
                          'sha256':hashlib.sha256(full_svg).hexdigest(),
                          'embedded_png_sha256':hashlib.sha256(full_png).hexdigest(),
                          'embedded_png_dimensions':original_dims,
                          'kind':'full-pixel PNG in raster-backed SVG; no native vector shapes'},
              'alpha_background':a.background,'output_path':str(output),
              'ports':{'input':incoming,'working':normalized,
                       'outputs':[jpg_port,svgz_port,full_svg_port]},
              'port_contract':'PORT_CONTRACT.md'}
    output.with_name(output.stem+'_report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(f'{output}  {len(jpg)} bytes  ({scaled.width} x {scaled.height}; JPEG quality {quality})')
    print(f'{full_svg_output}  {len(full_svg)} bytes  (full-size lossless PNG inside SVG)')
    print(f'{svgz_output}  {len(svgz)} bytes  (raster-backed SVG display; JPG detail limit)')


if __name__ == '__main__':
    main()
