@echo off
if "%~1"=="" (
  echo Drag an image file onto this .bat file.
  pause
  exit /b 1
)
py -3 "%~dp0compress_image.py" "%~1" --native-dimensions --target-kib auto
if errorlevel 1 (
  echo Export failed. Run setup_windows.bat first and check the error above.
  pause
  exit /b 1
)
echo Finished. The JPG, full-pixel SVG, compact SVGZ, and report are next to the original image.
pause
